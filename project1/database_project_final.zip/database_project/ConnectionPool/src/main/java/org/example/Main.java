package org.example;
import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {

        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUsername("postgres");// replace "User" by your User name
        dataSource.setPassword("/PostgreS@1478950+/");
        //replace "pwd" by your Password
        dataSource.setUrl("jdbc:postgresql://localhost:5432/project1");
        Connection connection = dataSource.getConnection();
        System.out.println(connection.getClass().getName());

//        dataSource.setInitialSize(3);
        dataSource.setMaxActive(3);

        String sql_insert = "......";
        try {
            PreparedStatement ps_insert = connection.prepareStatement(sql_insert);
            ps_insert.executeLargeUpdate();
            poolStatus(dataSource);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static void poolStatus(DruidDataSource dataSource) {
        System.out.println("Busy Num " + dataSource.getActiveCount());
        System.out.println("Close Num " + dataSource.getCloseCount());
        System.out.println("Recycle Num "+ dataSource.getRecycleCount());
        System.out.println("All Num " + dataSource.getConnectCount());

    }
}