package org.example;

import java.sql.Date;

// 文章类
class Article {
    private int id;                     // 主键
    private String title;               // 文章标题
    private String pubModel;            // 出版模式
    private Date dateCreated;           // 创建日期
    private Date dateCompleted;         // 完成日期
    private Integer journalId;          // 期刊ID（外键）
    private String authorLastName;      // 作者姓氏（外键）
    private Integer publicationTypeId;  // 出版类型ID（外键）
    private Integer grantId;            // 资助ID（外键）
    private Integer articleIdsId;       // 文章ID标识（外键）
    private Integer referencesArticleId; // 引用文章ID（外键）
}

// 作者类
class Author {
    private String collectiveName;      // 集体名称
    private String foreName;            // 名
    private String lastName;            // 姓
    private String initials;            // 缩写
    private String[] affiliation;       // 机构数组
    private boolean isCollectiveName;   // 是否为集体名称
}

// 期刊类
class Journal {
    private int id;                     // 主键
    private String country;             // 国家
    private String title;               // 期刊标题
    private String issn;                // ISSN号
    private JournalIssue[] journalIssues; // 期刊期号数组
}

// 期刊期号类（用于自定义类型）
class JournalIssue {
    private String issue;               // 期号
    private String volume;              // 卷号
}

// 关键词类
class Keyword {
    private String keyword;             // 关键词（主键）
}

// 文章-关键词关联类
class ArticleKeyword {
    private String keyword;             // 关键词（复合主键部分）
    private int articleId;              // 文章ID（复合主键部分）
}

// 资助类
class Grant {
    private String grantId;             // 资助ID
    private String acronym;             // 缩写
    private String country;             // 国家
    private String agency;              // 机构（主键）
}

// 文章-资助关联类
class ArticleGrant {
    private String agency;              // 机构（复合主键部分）
    private int articleId;              // 文章ID（复合主键部分）
}

// 文章ID类
class ArticleId {
    private int identity;               // 自增主键
    private String type;                // ID类型（pubmed或doi）
    private String id;                  // ID值
}

// 引用文章类
class ReferenceArticle {
    private int identity;               // 自增主键
    private String id;                  // 引用ID
}

// 出版类型类
class PublicationType {
    private int identity;               // 自增主键
    private String id;                  // 类型ID
    private String name;                // 类型名称
}

